import os
import subprocess

def check_root_status():
    try:
        # Mengecek status root dengan adb
        result = subprocess.check_output(["adb", "shell", "su", "-c", "id"], stderr=subprocess.STDOUT)
        if "uid=0" in result.decode():
            print("Root: YES")
        else:
            print("Root: NO")
    except subprocess.CalledProcessError:
        print("Root: NO")

def get_device_details():
    try:
        device_info = subprocess.check_output(["adb", "shell", "getprop"], stderr=subprocess.STDOUT)
        return device_info.decode()
    except subprocess.CalledProcessError:
        return "Failed to get device details."

def get_battery_status():
    try:
        battery_status = subprocess.check_output(["adb", "shell", "dumpsys", "battery"], stderr=subprocess.STDOUT)
        return battery_status.decode()
    except subprocess.CalledProcessError:
        return "Failed to get battery status."

def get_storage_info():
    try:
        storage_info = subprocess.check_output(["adb", "shell", "df"], stderr=subprocess.STDOUT)
        return storage_info.decode()
    except subprocess.CalledProcessError:
        return "Failed to get storage info."

def get_cpu_info():
    try:
        cpu_info = subprocess.check_output(["adb", "shell", "cat", "/proc/cpuinfo"], stderr=subprocess.STDOUT)
        return cpu_info.decode()
    except subprocess.CalledProcessError:
        return "Failed to get CPU info."

def get_memory_info():
    try:
        memory_info = subprocess.check_output(["adb", "shell", "cat", "/proc/meminfo"], stderr=subprocess.STDOUT)
        return memory_info.decode()
    except subprocess.CalledProcessError:
        return "Failed to get memory info."

def get_installed_packages():
    try:
        installed_packages = subprocess.check_output(["adb", "shell", "pm", "list", "packages"], stderr=subprocess.STDOUT)
        return installed_packages.decode()
    except subprocess.CalledProcessError:
        return "Failed to get installed packages."

def get_running_services():
    try:
        running_services = subprocess.check_output(["adb", "shell", "ps"], stderr=subprocess.STDOUT)
        return running_services.decode()
    except subprocess.CalledProcessError:
        return "Failed to get running services."

def get_screen_resolution():
    try:
        resolution = subprocess.check_output(["adb", "shell", "wm", "size"], stderr=subprocess.STDOUT)
        return resolution.decode()
    except subprocess.CalledProcessError:
        return "Failed to get screen resolution."

def take_screenshot():
    try:
        screenshot_path = "screenshot.png"
        subprocess.check_output(["adb", "shell", "screencap", "-p", "/sdcard/screenshot.png"], stderr=subprocess.STDOUT)
        subprocess.check_output(["adb", "pull", "/sdcard/screenshot.png", screenshot_path], stderr=subprocess.STDOUT)
        return f"Screenshot saved as {screenshot_path}"
    except subprocess.CalledProcessError:
        return "Failed to take screenshot."

def reboot_device():
    try:
        subprocess.check_output(["adb", "reboot"], stderr=subprocess.STDOUT)
        return "Device is rebooting..."
    except subprocess.CalledProcessError:
        return "Failed to reboot device."

def screen_record():
    try:
        duration = input("Enter recording duration in seconds (max 86400): ")
        if not duration.isdigit() or int(duration) > 86400 or int(duration) <= 0:
            return "Invalid duration. Please enter a number between 1 and 86400."

        video_path = "screen_record.mp4"
        print("Recording... Press Ctrl+C to stop if it hangs.")
        subprocess.check_output(["adb", "shell", "screenrecord", f"/sdcard/screen_record.mp4", "--time-limit", duration], stderr=subprocess.STDOUT)
        subprocess.check_output(["adb", "pull", "/sdcard/screen_record.mp4", video_path], stderr=subprocess.STDOUT)
        print(f"Screen recording saved as {video_path}")
    except subprocess.CalledProcessError:
        print("Failed to record screen. Ensure your device supports screen recording and is connected via ADB.")
    except KeyboardInterrupt:
        print("\nScreen recording stopped manually.")

def change_device_language(language_code):
    try:
        subprocess.check_output(["adb", "shell", "setprop", "persist.sys.language", language_code], stderr=subprocess.STDOUT)
        subprocess.check_output(["adb", "shell", "setprop", "persist.sys.country", "US"], stderr=subprocess.STDOUT)
        return f"Device language changed to {language_code}"
    except subprocess.CalledProcessError:
        return "Failed to change device language."

def factory_reset():
    try:
        subprocess.check_output(["adb", "shell", "am", "broadcast", "-a", "android.intent.action.MASTER_CLEAR"], stderr=subprocess.STDOUT)
        return "Factory reset initiated."
    except subprocess.CalledProcessError:
        return "Failed to initiate factory reset."

def unlock_bootloader():
    try:
        subprocess.check_output(["fastboot", "oem", "unlock"], stderr=subprocess.STDOUT)
        return "Bootloader unlock initiated. Follow device instructions."
    except subprocess.CalledProcessError:
        return "Failed to unlock bootloader. Ensure your device is in fastboot mode."

def fastboot_root():
    try:
        print("Make sure your device is in fastboot mode.")
        print("Ensure you have the correct root files for your device.")
        boot_image = input("Enter the path to the patched boot image: ")

        if not os.path.exists(boot_image):
            return "Patched boot image file not found."

        subprocess.check_output(["fastboot", "flash", "boot", boot_image], stderr=subprocess.STDOUT)
        subprocess.check_output(["fastboot", "reboot"], stderr=subprocess.STDOUT)
        return "Device rooted and rebooted successfully."
    except subprocess.CalledProcessError:
        return "Failed to root device. Ensure it is in fastboot mode and try again."

def main():
    print("Choose an option:")
    print("1. Get Device Details")
    print("2. Get Battery Status")
    print("3. Get Storage Info")
    print("4. Get CPU Info")
    print("5. Get Memory Info")
    print("6. Get Installed Packages")
    print("7. Get Running Services")
    print("8. Get Screen Resolution")
    print("9. Take Screenshot")
    print("10. Reboot Device")
    print("11. Check Root Status")
    print("12. Start Screen Recording")
    print("13. Change Device Language")
    print("14. Factory Reset")
    print("15. Unlock Bootloader")
    print("16. Fastboot Root")

    choice = input("Enter your choice: ")

    if choice == "1":
        print(get_device_details())
    elif choice == "2":
        print(get_battery_status())
    elif choice == "3":
        print(get_storage_info())
    elif choice == "4":
        print(get_cpu_info())
    elif choice == "5":
        print(get_memory_info())
    elif choice == "6":
        print(get_installed_packages())
    elif choice == "7":
        print(get_running_services())
    elif choice == "8":
        print(get_screen_resolution())
    elif choice == "9":
        print(take_screenshot())
    elif choice == "10":
        print(reboot_device())
    elif choice == "11":
        check_root_status()
    elif choice == "12":
        print(screen_record())
    elif choice == "13":
        language_code = input("Enter the language code (e.g., en, es, fr): ")
        print(change_device_language(language_code))
    elif choice == "14":
        print(factory_reset())
    elif choice == "15":
        print(unlock_bootloader())
    elif choice == "16":
        print(fastboot_root())
    else:
        print("Invalid choice.")

if __name__ == "__main__":
    main()
